<H1>About Me</H1>
<H2>My Interests</H2>

1. I like to  watch anime

![I like to watch anime][anime]

[anime]: https://www.superherotoystore.com/cdn/shop/articles/Website_Blog_creatives_29_2000x.progressive.jpg?v=1713945144

2. I like to try cute desserts!
![I enjoy trying new foods,especially desserts.][desserts]

[desserts]: https://s3-media0.fl.yelpcdn.com/bphoto/dAkrCOCKNWdHt3cn4GGHSg/o.jpg

3. I love to go on the hunt for new plushies, pops, and games.

![I love to go on the hunt for new plushies, pops, and games.][games]

[games]: https://images.stockcake.com/public/e/7/e/e7eb7075-2666-452a-9aa0-c3b586c7ac0e_large/cozy-gaming-setup-stockcake.jpg



<H2>Websites I Recommend</H2>

1. If you like to watch animelike me or are interested in anime, I would suggest likes like: [Crunchyroll](www.crunchyroll.com)

2. If you want to find cute, delcious desserts, but dont know where to start? I would suggest:
   
   * [Bombolonis](https://www.facebook.com/paulandjackbakery/?_rdr) anyone?
     
   * [Canelés](https://lucettegrace.com/) anyone?
  
   * [Curry Donuts](https://parisbaguette.com/product/curry-croquette/)
  
  3. Looking for new games, plushies, and figures?
   * For [the ultimate fan **+** amazing pop dolls](https://www.boxlunch.com/)

   * For [the pc gamer extraordinaire](https://store.steampowered.com/)

   * For [**EVEN _MORE_ PLUSHIES**](https://miniso-us.com/pages/products)

Mallory Jones - majones3@my.waketech.edu
This is my school account
<This repository will hold my assignments and projects
**CyberSecChick007/CyberSecChick007** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working at Amazon which is a real workout
- 🌱 I’m currently learning all othe 1st semester tech courses
- 👯 I’m looking to learn how to become the most effective and efficient learn I can
- 🤔 I’m looking for help with understanding concepts NOT just terminology
- 💬 Ask me about what my favorite anime is, foods I like, and places I want to trave
- 📫 How to reach me: the best way to reach me is through school email 
- 😄 Pronouns: she, her, her ladyship (jk)
- ⚡ Fun fact: I can move my left ear
-->
