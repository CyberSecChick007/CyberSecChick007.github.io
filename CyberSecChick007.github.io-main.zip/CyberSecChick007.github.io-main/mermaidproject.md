How to have Good Dental Health at Home 

First you need to go to a local grocery store and then once you are inside the dental section pick out: a tongue scraper, toothbrush, toothpaste, mouthwash, floss. Once you make it home go to the bathroom: get your toothbrush wet, put toothpaste on your toothbrush, brush your teeth. Be sure to brush all your teeth! After you are done brushing your teeth, rinse your mouth out with water and spit out the gross liquid. After you are done brushing your teeth take out your tongue scraper, and scrape your tongue then spit out the gross tongue film. Once you’re down scraping your tongue, flossing your teeth, remember to get don't your back teeth. After you've rinsed your mouth out with water grab your mouthwash bottle, please be sure to read instructions before using. After you've read the instructions take the cap of and pour the recommended amount of mouthwash. Once you’re sure of the instructions, swish the cap full of mouthwash in your mouth for the recommended amount of time. After you’ve rinsed your mouth with mouthwash for at least 1-2 minutes, spit out mouthwash. Once you’ve swished the mouthwash out for the recommended amount of time spit out your mouthwash. Now your teeth are clean!






```mermaid
 
 flowchart TB
    A[How to have Good Dental Health at Home] -->|Go to the Store| B(Go the Dental Section)
    B --> C{Pick Out:
    -A Tongue Scraper
    -Toothbrush
    -Toothpaste
    -Mouthwash
    -Floss}
    C -->|One| D[-Go to the bathroom 
     -Wet your Toothbrush 
     -Put toothpaste on your Toothbrush 
     -Brush your teeth]
    C -->|Two| E[-Rinse your mouth out
    -Scrape your Tongue
    -Floss your teeth
    -Rinse your mouth out]
    C -->|Three| F[-Rinse your mouth with mouthwash for at least 1-2 minutes
    -Spit out mouthwash]
    D-->H{Clean Teeth}
    E-->H{Clean Teeth} 
    F--> H{Clean Teeth}
    
